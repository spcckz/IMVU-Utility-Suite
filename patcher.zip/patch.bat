rem this is a batch file - can you comment out everything related to option 8 - so it's still there - but can't be used if i do the "all options" option?

@echo off
cd /d "%~dp0"
title IMVU Patcher

rem ------------------------------------------------------------
rem  IMVU Patcher - feature menu
rem  Each feature lives in features\<name> with its own patch_spec.
rem  Apply, check, and restore operate per-feature.
rem ------------------------------------------------------------

set "ROOT=%~dp0"
set "FEATDIR=%ROOT%features"
set "CLIENTROOT="
call :find_client_root
set "PY=py -3.8"
py -3.8 -V >nul 2>&1
if errorlevel 1 (
    py -3 -V >nul 2>&1
    if not errorlevel 1 set "PY=py -3"
)

if not defined CLIENTROOT (
    echo ERROR: could not locate the IMVU client root.
    echo Put patch.bat inside IMVUClient\!PROJECT\patcher or IMVUClient\patcher and make sure library.zip exists.
    pause
    exit /b 1
)
if not exist "%CLIENTROOT%\library.zip" (
    echo ERROR: client root not found at "%CLIENTROOT%"
    echo Put patch.bat inside IMVUClient\!PROJECT\patcher or IMVUClient\patcher and make sure library.zip exists.
    pause
    exit /b 1
)

:menu
cls
echo ==========================================================
echo                 IMVU Feature Patcher
echo ==========================================================
echo  Client : %CLIENTROOT%
echo.
echo  Pick a feature to APPLY, or use check/restore:
echo.
echo   [1] Mute            - always show Mute in avatar safety
echo   [2] Camera          - re-enable photo button in chat
echo   [3] Less Ads        - disable client ads + sponsored badges
echo   [4] No Tracking     - disable Send IMVU Logs reporting
echo   [5] Invite Timer    - room invite timer 5 -^> 15 minutes
echo   [6] Hi-Res Snapshot - hi-res snapshots anywhere + menu items
echo   [7] Chat Colors     - nametag color randomizer button in chat
rem echo   [8] Auto-Mute       - auto-hide blocked users from chat
echo   [A] Apply ALL features
echo.
echo   [S] Setup Python    - install Python 3.x + Python 2.7 for the patcher
echo   [C] Check status of all features
echo   [R] Restore a feature from backup
echo   [X] Exit
echo.
set /p "choice=Select: "
echo.

if /i "%choice%"=="1"  call :apply_feature mute
if /i "%choice%"=="2"  call :apply_feature camera
if /i "%choice%"=="3"  call :apply_feature ads
if /i "%choice%"=="4"  call :apply_feature no-tracking
if /i "%choice%"=="5"  call :apply_feature invite-timer
if /i "%choice%"=="6"  call :apply_feature hires-snap
if /i "%choice%"=="7"  call :apply_feature chat-colors
rem if /i "%choice%"=="8"  call :apply_feature auto-mute
if /i "%choice%"=="a"  call :apply_all
if /i "%choice%"=="s"  call :setup_environment
if /i "%choice%"=="c"  call :check_all
if /i "%choice%"=="r"  call :restore_menu
if /i "%choice%"=="x"  exit /b 0
if "%choice%"=="" exit /b 0
pause
goto :menu

rem ------------------------------------------------------------
:find_client_root
for %%D in ("%ROOT%..", "%ROOT%..\..", "%ROOT%..\..\..") do (
    if exist "%%~fD\library.zip" (
        set "CLIENTROOT=%%~fD"
        goto :client_root_found
    )
)
exit /b 0

:client_root_found
exit /b 0

rem ------------------------------------------------------------
:setup_environment
echo.
echo Running first-time setup...
echo This will install the Python runtimes the patcher needs if they are missing.
echo It will install winget first if necessary, then use it to install Python.
echo.
call :ensure_python3
if errorlevel 1 (
    echo.
    echo Python 3 setup failed.
    pause
    exit /b 1
)
call :ensure_python27
if errorlevel 1 (
    echo.
    echo Python 2.7 setup failed.
    pause
    exit /b 1
)

echo.
echo Verifying the patcher runtime...
py -3.8 -V >nul 2>&1
if errorlevel 1 (
    py -3 -V >nul 2>&1
    if errorlevel 1 (
        echo ERROR: no usable Python 3 runtime was found.
        pause
        exit /b 1
    )
    set "PY=py -3"
) else (
    set "PY=py -3.8"
)
py -2.7 -V >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python 2.7 is still not available.
    pause
    exit /b 1
)

echo.
echo Installing pip (if needed)...
%PY% -m pip install --upgrade pip >nul 2>&1

echo.
echo Setup complete. Re-run patch.bat and pick a feature.
pause
exit /b 0

rem ------------------------------------------------------------
:ensure_python3
py -3.8 -V >nul 2>&1
if not errorlevel 1 (
    echo Python 3.8 detected.
    set "PY=py -3.8"
    exit /b 0
)
py -3 -V >nul 2>&1
if not errorlevel 1 (
    echo Python 3 detected.
    set "PY=py -3"
    exit /b 0
)

echo Python 3 was not found. Trying to install it...
call :ensure_winget
if errorlevel 1 (
    echo Winget could not be set up automatically.
    echo Please install Python 3 manually from https://www.python.org/downloads/windows/
    exit /b 1
)
echo Installing Python 3.11 with winget...
winget install --id Python.Python.3.11 -e --accept-source-agreements --accept-package-agreements --silent >nul 2>&1
py -3.8 -V >nul 2>&1
if not errorlevel 1 (
    set "PY=py -3.8"
    exit /b 0
)
py -3 -V >nul 2>&1
if not errorlevel 1 (
    set "PY=py -3"
    exit /b 0
)

echo Python 3 installation did not become available yet.
echo Please reopen the terminal and run Setup Python again if needed.
exit /b 1

rem ------------------------------------------------------------
:ensure_winget
where winget >nul 2>&1
if not errorlevel 1 (
    echo winget is already available.
    exit /b 0
)

echo winget was not found. Installing App Installer from the Microsoft Store...
where powershell >nul 2>&1
if errorlevel 1 (
    echo PowerShell is required for automated winget setup.
    exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process 'ms-windows-store://pdp/?productid=9NBLGGH4NNS1'" >nul 2>&1

echo Please install the App Installer package from the Microsoft Store, then re-run Setup Python.
pause
exit /b 1

rem ------------------------------------------------------------
:ensure_python27
py -2.7 -V >nul 2>&1
if not errorlevel 1 (
    echo Python 2.7 detected.
    exit /b 0
)

echo Python 2.7 was not found. Trying to install it...
where powershell >nul 2>&1
if errorlevel 1 (
    echo PowerShell is required for automated fallback installation.
    exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$tmp='%TEMP%\python2.7.18-amd64.msi'; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/2.7.18/python-2.7.18.amd64.msi' -OutFile $tmp; Start-Process $tmp -Wait -ArgumentList '/qn /norestart'" >nul 2>&1
if errorlevel 1 (
    echo Python 2.7 installation failed.
    echo Please install it manually from https://www.python.org/downloads/release/python-2718/
    exit /b 1
)
py -2.7 -V >nul 2>&1
if errorlevel 1 (
    echo Python 2.7 installation did not become available yet.
    echo Please reopen the terminal and run Setup Python again.
    exit /b 1
)
echo Python 2.7 installed successfully.
exit /b 0

rem ------------------------------------------------------------
:apply_all
for %%F in (mute camera ads no-tracking invite-timer hires-snap chat-colors) do (
    echo.
    echo ============ Feature: %%F ============
    call :apply_feature %%F
)
exit /b 0

rem ------------------------------------------------------------
:apply_feature
set "FEAT=%~1"
echo Applying feature "%FEAT%" ...
%PY% "%ROOT%patcher.py" --client-root "%CLIENTROOT%" --spec-dir "%FEATDIR%\%FEAT%" --apply --force
echo.
echo [%FEAT%] done - exit code %errorlevel%
exit /b 0

rem ------------------------------------------------------------
:check_all
for %%F in (mute camera ads no-tracking invite-timer hires-snap chat-colors) do (
    echo.
    echo ============ Feature: %%F ============
    %PY% "%ROOT%patcher.py" --client-root "%CLIENTROOT%" --spec-dir "%FEATDIR%\%%F" --check
)
pause
exit /b 0

rem ------------------------------------------------------------
:restore_menu
echo.
echo Available feature backups:
echo.
for %%F in (mute camera ads no-tracking invite-timer hires-snap chat-colors) do (
    echo  --- %%F ---
    for /d %%B in ("%FEATDIR%\%%F\backup\*") do (
        echo     %%~nxB
    )
)
echo.
set /p "backup=Backup folder name to restore (leave empty to cancel): "
if "%backup%"=="" exit /b 0
set /p "feat=Feature dir [mute/camera/ads/no-tracking/invite-timer/hires-snap/chat-colors/auto-mute]: "
if not exist "%FEATDIR%\%feat%\backup\%backup%" (
    echo ERROR: no such backup.
    pause
    exit /b 0
)
%PY% "%ROOT%patcher.py" --client-root "%CLIENTROOT%" --spec-dir "%FEATDIR%\%feat%" --restore "%backup%"
echo.
echo Restored. Re-apply the feature later from the main menu.
pause
exit /b 0
