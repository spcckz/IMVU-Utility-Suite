#!/usr/bin/env python3
"""
IMVU Client Patcher
===================
Applies persistent modifications (described in patch_spec.txt) to the IMVU
client's library.zip and ui\\chrome\\imvuContent.jar, then re-syncs the
extracted content directory and updates the CRC32 lines in checksum.txt.

The point of the tool is persistence across IMVU client updates: whenever the
client is updated (and the archives revert to vanilla), simply run
`python patcher.py --apply` again to re-apply every modification described in
patch_spec.txt.

Usage:
    python patcher.py --apply       apply all patches (backing up first)
    python patcher.py --apply --force   apply even if files changed upstream
    python patcher.py --check       report patch state for every spec entry
    python patcher.py --dry-run     show what --apply would do, write nothing
    python patcher.py --restore NAME    restore files from backup/NAME
    python patcher.py --client-root DIR override the client install directory

Spec format (patch_spec.txt)
----------------------------
One block per operation, blocks separated by blank lines. Comments start with
'#'. Each block is a set of `key = value` lines.

Common keys:
    kind    = replace | pyo | patch | delete   (required)
    archive = path of archive relative to the client root,
              e.g. library.zip or ui/chrome/imvuContent.jar
    file    = path of the entry inside the archive (replace/pyo/patch)
              OR a path relative to the client root (delete)
    baseline= (optional) sha1 hex of the pristine entry that this patch was
              authored against. Used to detect upstream changes on re-runs.

Kind 'replace' - swap in a whole file:
    source  = path (relative to this spec) of the replacement file

Kind 'pyo'    - compile Python source with Python 2.7 -O and swap in the .pyo:
    source  = path (relative to this spec) of the .py source file

Kind 'patch'  - surgical find/replace on the extracted entry:
    find_file    = path to a file containing the exact text to locate
    replace_file = path to a file containing the exact replacement text
                   (may be empty)

Kind 'delete' - remove a file from the client root (backed up first, and its
    checksum.txt entry is pruned so the updater leaves it deleted):
    file    = path relative to the client root, e.g. devicefingerprint.exe
"""

import argparse
import hashlib
import os
import shutil
import subprocess
import sys
import time
import zipfile
import zlib
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent


def detect_client_root(script_dir):
    for candidate in (script_dir, script_dir.parent, script_dir.parent.parent):
        if (candidate / "library.zip").is_file():
            return str(candidate)
    return str(script_dir.parent.parent)


DEFAULT_CLIENT_ROOT = detect_client_root(SCRIPT_DIR)

SPEC_NAME = "patch_spec.txt"
KINDS = ("replace", "pyo", "patch", "delete")


class SpecError(Exception):
    pass


class PatchError(Exception):
    pass


def sha1_hex(data):
    return hashlib.sha1(data).hexdigest()


def crc32_file(path):
    with open(path, "rb") as fh:
        return zlib.crc32(fh.read()) & 0xFFFFFFFF


def parse_spec(text):
    ops = []
    for block in text.split("\n\n"):
        block = block.strip()
        if not block:
            continue
        op = {}
        for line in block.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                raise SpecError("Bad spec line (expected key = value): %r" % line)
            key, value = line.split("=", 1)
            op[key.strip()] = value.strip()
        if not op:
            continue
        if "kind" not in op:
            raise SpecError("Spec block missing 'kind': %r" % (op,))
        if op["kind"] not in KINDS:
            raise SpecError("Unknown kind %r (expected %s)" % (op["kind"], ", ".join(KINDS)))
        if op["kind"] == "delete":
            if "file" not in op:
                raise SpecError("'delete' block missing 'file': %r" % (op,))
        else:
            for field in ("archive", "file"):
                if field not in op:
                    raise SpecError("Spec block missing '%s': %r" % (field, op))
            if op["kind"] == "replace":
                if "source" not in op:
                    raise SpecError("'replace' block missing 'source': %r" % (op,))
            elif op["kind"] == "pyo":
                if "source" not in op:
                    raise SpecError("'pyo' block missing 'source': %r" % (op,))
            elif op["kind"] == "patch":
                for field in ("find_file", "replace_file"):
                    if field not in op:
                        raise SpecError("'patch' block missing '%s': %r" % (field, op))
        ops.append(op)
    if not ops:
        raise SpecError("No operations found in spec.")
    return ops


class Patcher(object):
    def __init__(self, client_root, spec_dir, py27_cmd):
        self.client_root = Path(client_root)
        self.spec_dir = Path(spec_dir)
        self.py27_cmd = list(py27_cmd)
        self.checksum_path = self.client_root / "checksum.txt"
        self.backup_dir = self.spec_dir / "backup"

    # ---- path helpers ------------------------------------------------------

    def archive_path(self, rel):
        path = self.client_root / rel.replace("/", os.sep)
        if not path.is_file():
            raise PatchError("Archive not found: %s" % path)
        return path

    def spec_file(self, ref):
        path = self.spec_dir / ref.replace("/", os.sep)
        if not path.is_file():
            raise PatchError("Spec source not found: %s" % path)
        return path

    def extracted_base(self, archive_rel):
        if "imvuContent.jar" not in archive_rel:
            return None
        return self.client_root / "ui" / "chrome" / "imvucontentjar"

    # ---- archive helpers ---------------------------------------------------

    @staticmethod
    def read_archive(path):
        with zipfile.ZipFile(path) as zh:
            return {info.filename: (info, zh.read(info.filename)) for info in zh.infolist()}

    @staticmethod
    def write_archive(path, entries):
        tmp = path.with_suffix(path.suffix + ".tmp")
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED) as zh:
            for filename, (info, data) in entries.items():
                zh.writestr(info, data)
        os.replace(tmp, path)

    @staticmethod
    def verify_archive(path, expected_entries):
        with zipfile.ZipFile(path) as zh:
            bad = zh.testzip()
            if bad is not None:
                raise PatchError("Rebuilt archive corrupt at entry %r" % bad)
            for filename, expected in expected_entries.items():
                if zh.read(filename) != expected:
                    raise PatchError("Rebuilt archive entry %r does not match expected bytes" % filename)

    # ---- op execution ------------------------------------------------------

    def compute_expected(self, op, current):
        kind = op["kind"]
        if kind == "replace":
            return self.spec_file(op["source"]).read_bytes()
        if kind == "pyo":
            return self.compile_pyo(self.spec_file(op["source"]))
        if kind == "patch":
            find = self.spec_file(op["find_file"]).read_bytes()
            replace = self.spec_file(op["replace_file"]).read_bytes()
            if find not in current:
                raise PatchError("Anchor not found in %s (%s)" % (op["file"], op["archive"]))
            if current.count(find) > 1:
                print("  warning: anchor occurs %d times in %s; patching first" %
                      (current.count(find), op["file"]))
            return current.replace(find, replace, 1)
        raise PatchError("Unknown kind %r" % kind)

    def compile_pyo(self, src):
        # Use a fixed work directory so the path embedded in the compiled
        # bytecode is stable across runs (py_compile stores co_filename,
        # which makes output deterministic for a given source + mtime).
        work = self.spec_dir / ".pyo_work"
        shutil.rmtree(work, ignore_errors=True)
        work.mkdir(parents=True, exist_ok=True)
        tmp_src = work / src.name
        shutil.copy2(src, tmp_src)
        proc = subprocess.run(self.py27_cmd + ["-m", "py_compile", str(tmp_src)],
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if proc.returncode != 0:
            raise PatchError("py2.7 compile failed:\n" +
                             proc.stderr.decode("utf-8", "replace"))
        pyo = tmp_src.with_suffix(".pyo")
        if not pyo.exists():
            pyc = tmp_src.with_suffix(".pyc")
            if pyc.exists():
                pyo = pyc
        if not pyo.exists():
            raise PatchError("py_compile produced no output file for %s" % src.name)
        return pyo.read_bytes()

    def state_of(self, current, op):
        """Return 'applied', 'base', or 'modified' for the given entry."""
        if op["kind"] == "patch":
            find = self.spec_file(op["find_file"]).read_bytes()
            replace = self.spec_file(op["replace_file"]).read_bytes()
            if find in current:
                return "base"
            if replace and replace in current:
                return "applied"
            if not replace:
                # pure removal: find absent means removal already applied
                return "applied"
            return "modified"
        baseline = op.get("baseline")
        if baseline and sha1_hex(current) == baseline:
            return "base"
        try:
            expected = self.compute_expected(op, current)
        except PatchError:
            return "modified"
        if current == expected:
            return "applied"
        return "modified"

    # ---- flow --------------------------------------------------------------

    def plan(self, ops):
        """Return list of dicts: op, archive path, filename, current, expected, state."""
        planned = []
        for op in ops:
            if op["kind"] == "delete":
                target = self.client_root / op["file"].replace("/", os.sep)
                planned.append({
                    "op": op,
                    "archive_path": target,
                    "archive_rel": op["file"],
                    "filename": op["file"],
                    "current": None,
                    "expected": None,
                    "state": "applied" if not target.exists() else "base",
                    "is_delete": True,
                })
                continue
            archive_path = self.archive_path(op["archive"])
            entries = self.read_archive(archive_path)
            filename = op["file"]
            if filename not in entries:
                raise PatchError("Entry %r not found in %s" % (filename, op["archive"]))
            current = entries[filename][1]
            state = self.state_of(current, op)
            expected = None
            if state == "base":
                expected = self.compute_expected(op, current)
            else:
                # Keep the replacement bytes available for --force even when
                # state is "modified" (replace/pyo kinds can always compute).
                try:
                    expected = self.compute_expected(op, current)
                except PatchError:
                    expected = None
            planned.append({
                "op": op,
                "archive_path": archive_path,
                "archive_rel": op["archive"],
                "filename": filename,
                "current": current,
                "expected": expected,
                "state": state,
            })
        return planned

    def apply_plan(self, planned, force):
        """Apply the plan in memory. Returns list of (plan_item, applied_bool)."""
        results = []
        for item in planned:
            if item["state"] == "applied":
                results.append((item, False))
                continue
            if item["state"] == "modified" and not force:
                results.append((item, False))
                continue
            results.append((item, True))
        return results

    def write_changes(self, planned, results):
        """Persist applied changes: rewrite archives, sync extracted dir, checksums."""
        applied_by_archive = {}
        for item, applied in results:
            if applied and not item.get("is_delete"):
                applied_by_archive.setdefault(item["archive_rel"], []).append(item)

        patched_archives = []
        for rel, items in applied_by_archive.items():
            path = self.archive_path(rel)
            entries = self.read_archive(path)
            expected = {}
            for item in items:
                op = item["op"]
                filename = item["filename"]
                data = entries[filename][1]
                if op["kind"] == "patch":
                    # apply sequentially so multiple patch ops on one entry chain
                    find = self.spec_file(op["find_file"]).read_bytes()
                    replace = self.spec_file(op["replace_file"]).read_bytes()
                    if find not in data:
                        raise PatchError("Anchor not found in %s (%s)" % (filename, rel))
                    data = data.replace(find, replace, 1)
                else:
                    if item["expected"] is None:
                        raise PatchError("Cannot compute replacement for %s (%s)" %
                                         (filename, rel))
                    data = item["expected"]
                entries[filename] = (entries[filename][0], data)
                expected[filename] = data
            self.write_archive(path, entries)
            self.verify_archive(path, expected)
            patched_archives.append(rel)
            print("  wrote %s (%d entries)" % (path, len(entries)))

            base = self.extracted_base(rel)
            if base is not None:
                for item in items:
                    dest = base / item["filename"].replace("/", os.sep)
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_bytes(item["expected"])
                    print("  synced %s" % dest)

        if patched_archives:
            self.update_checksums(patched_archives)

    def update_checksums(self, patched_archives):
        if not self.checksum_path.is_file():
            print("  warning: checksum.txt not found; skipping checksum update")
            return
        with open(self.checksum_path, "r", newline="") as fh:
            lines = fh.readlines()
        changed = []
        for rel in patched_archives:
            path = self.archive_path(rel)
            crc = crc32_file(path)
            norm = rel.replace("/", "\\")
            hit = False
            for i, line in enumerate(lines):
                parts = line.split()
                if len(parts) >= 2 and parts[1].replace("/", "\\").lower() == norm.lower():
                    lines[i] = "%d %s%s" % (crc, parts[1], line[len(line.rstrip("\r\n")):])
                    changed.append(rel)
                    hit = True
                    break
            if not hit:
                lines.append("%d %s\n" % (crc, norm))
                changed.append(rel)
        if changed:
            with open(self.checksum_path, "w", newline="") as fh:
                fh.writelines(lines)
            print("  checksum.txt updated for: %s" % ", ".join(changed))

    def checksum_mismatches(self):
        """Return list of (rel, on_disk_crc, expected_crc) for the two archives."""
        result = []
        if not self.checksum_path.is_file():
            return result
        expected = {}
        with open(self.checksum_path, "r", newline="") as fh:
            for line in fh:
                parts = line.split()
                if len(parts) >= 2 and parts[0].isdigit():
                    expected[parts[1].replace("\\", "/")] = int(parts[0])
        for rel in ("library.zip", "ui/chrome/imvuContent.jar"):
            path = self.client_root / rel.replace("/", os.sep)
            if not path.is_file():
                continue
            crc = crc32_file(path)
            want = expected.get(rel)
            if want is not None and crc != want:
                result.append((rel, crc, want))
        return result

    # ---- backup / restore --------------------------------------------------

    def make_backup(self, archives, deletes=None):
        stamp = time.strftime("%Y%m%d-%H%M%S")
        dest = self.backup_dir / stamp
        dest.mkdir(parents=True, exist_ok=True)
        for rel in archives:
            path = self.client_root / rel.replace("/", os.sep)
            if path.is_file():
                shutil.copy2(path, dest / path.name)
        for item in (deletes or []):
            path = self.client_root / item["op"]["file"].replace("/", os.sep)
            if path.is_file():
                shutil.copy2(path, dest / ("deleted_" + path.name))
        if self.checksum_path.is_file():
            shutil.copy2(self.checksum_path, dest / "checksum.txt")
        print("  backup -> %s" % dest)
        return stamp

    def apply_delete(self, item):
        path = self.client_root / item["op"]["file"].replace("/", os.sep)
        if path.exists():
            path.unlink()
            print("  deleted %s" % item["op"]["file"])
        self.prune_checksum(item["op"]["file"])

    def prune_checksum(self, file_rel):
        if not self.checksum_path.is_file():
            return
        norm = file_rel.replace("/", "\\").lower()
        with open(self.checksum_path, "r", newline="") as fh:
            lines = fh.readlines()
        kept = []
        for line in lines:
            parts = line.split()
            if len(parts) >= 2 and parts[1].replace("/", "\\").lower() == norm:
                continue
            kept.append(line)
        if len(kept) != len(lines):
            with open(self.checksum_path, "w", newline="") as fh:
                fh.writelines(kept)
            print("  checksum.txt: removed entry for %s" % file_rel)

    def list_backups(self):
        if not self.backup_dir.is_dir():
            return []
        return sorted(d.name for d in self.backup_dir.iterdir() if d.is_dir())

    def restore(self, name):
        src = self.backup_dir / name
        if not src.is_dir():
            raise PatchError("Backup not found: %s (have: %s)" % (name, ", ".join(self.list_backups())))
        restored = []
        for f in src.iterdir():
            if f.name == "checksum.txt":
                shutil.copy2(f, self.checksum_path)
                restored.append("checksum.txt")
            elif f.name == "library.zip":
                shutil.copy2(f, self.client_root / "library.zip")
                restored.append("library.zip")
            elif f.name == "imvuContent.jar":
                shutil.copy2(f, self.client_root / "ui" / "chrome" / "imvuContent.jar")
                restored.append("ui/chrome/imvuContent.jar")
            elif f.name.startswith("deleted_"):
                target = self.client_root / f.name[len("deleted_"):]
                shutil.copy2(f, target)
                restored.append(f.name[len("deleted_"):] + " (restored)")
        print("Restored from %s: %s" % (name, ", ".join(restored)))
        print("Note: re-run --apply to re-sync the extracted ui/chrome/imvucontentjar dir if needed.")


def main(argv=None):
    ap = argparse.ArgumentParser(description="IMVU client patcher")
    ap.add_argument("--client-root", default=str(DEFAULT_CLIENT_ROOT),
                    help="IMVU install directory (auto-detected when possible)")
    ap.add_argument("--spec-dir", default=str(SCRIPT_DIR), help="directory containing patch_spec.txt")
    ap.add_argument("--py27", default=["py", "-2.7", "-O"], nargs="*",
                    help="command used to compile .py to .pyo (default: py -2.7 -O)")
    ap.add_argument("--apply", action="store_true", help="apply all patches")
    ap.add_argument("--check", action="store_true", help="report patch state")
    ap.add_argument("--dry-run", action="store_true", help="report planned changes without writing")
    ap.add_argument("--force", action="store_true", help="apply even if files changed upstream")
    ap.add_argument("--restore", metavar="NAME", help="restore files from a backup")
    args = ap.parse_args(argv)

    p = Patcher(args.client_root, args.spec_dir, args.py27)

    if args.restore:
        p.restore(args.restore)
        return 0

    spec_path = p.spec_dir / SPEC_NAME
    if not spec_path.is_file():
        print("Spec not found: %s" % spec_path, file=sys.stderr)
        return 1

    try:
        ops = parse_spec(spec_path.read_text())
        planned = p.plan(ops)
    except (SpecError, PatchError) as exc:
        print("ERROR: %s" % exc, file=sys.stderr)
        return 1

    if args.apply:
        results = p.apply_plan(planned, args.force)
        print("\nApplying:")
        for item, applied in results:
            mark = "PATCHED" if applied else "skip"
            if not applied and item["state"] == "applied":
                mark = "already applied" if not item.get("is_delete") else "already deleted"
            if not applied and item["state"] == "modified":
                mark = "SKIPPED (changed upstream; use --force)"
            if item.get("is_delete"):
                print("  [%s] %-22s %s" % (mark, "<client root>", item["filename"]))
            else:
                print("  [%s] %-22s %s" % (mark, item["archive_rel"], item["filename"]))
        applied_archives = sorted({item["archive_rel"] for item, applied in results
                                   if applied and not item.get("is_delete")})
        applied_deletes = [item for item, applied in results if applied and item.get("is_delete")]
        if not applied_archives and not applied_deletes:
            print("Nothing to patch.")
            return 0
        print("\nBacking up before patching...")
        p.make_backup(applied_archives, applied_deletes)
        print("\nWriting archives and syncing...")
        p.write_changes(planned, results)
        for item in applied_deletes:
            p.apply_delete(item)
        mism = p.checksum_mismatches()
        print("\nChecksum consistency:")
        for rel, crc, want in mism:
            print("  MISMATCH %s: on-disk=%d checksum.txt=%d" % (rel, crc, want))
        if not mism:
            print("  all archives match checksum.txt")
        print("\nDone.")
        return 0

    # check / dry-run
    print("Patch state:")
    all_applied = True
    for item in planned:
        state = item["state"]
        if state != "applied":
            all_applied = False
        if item.get("is_delete"):
            desc = "deleted" if state == "applied" else "present (will delete)"
        else:
            desc = {"applied": "applied", "base": "base (patchable)",
                    "modified": "MODIFIED (upstream change?)"}[state]
        if item.get("is_delete"):
            print("  [%s] %-22s %s" % (desc, "<client root>", item["filename"]))
        else:
            print("  [%s] %-22s %s" % (desc, item["archive_rel"], item["filename"]))
        if args.dry_run and state == "base":
            print("        would patch (sha1 %s)" % sha1_hex(item["expected"]))
    mism = p.checksum_mismatches()
    for rel, crc, want in mism:
        print("  [checksum] %s: on-disk=%d checksum.txt=%d" % (rel, crc, want))
    if not mism:
        print("  [checksum] archives match checksum.txt")
    if args.dry_run:
        print("\nDry run only - nothing was written.")
    return 0 if all_applied else 1


if __name__ == "__main__":
    sys.exit(main())
