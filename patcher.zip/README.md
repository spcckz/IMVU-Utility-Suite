# IMVU Patcher Suite

Double-click **patch.bat** for the interactive feature menu. It applies
modifications to the installed IMVU Classic client (553.18) without downgrading.

All features are always-on, no license gating, and no IMVULite DRM/anti-piracy
code is included. POW security (`ProofOfWork`) in the client is untouched.

## Features

| # | Folder       | What it does                                                        | Files patched                                            |
|---|--------------|---------------------------------------------------------------------|----------------------------------------------------------|
| 1 | `mute`       | Always show the Mute section in the Avatar Safety dialog            | `dialogs/avatar_safety/avatarSafety.js`                  |
| 2 | `camera`     | Re-enable the photo button in chat rooms                            | `imvu/mode/Mode.pyo`                                     |
| 3 | `ads`        | Disable client ads, sponsored shop badges, home sledgehammer, fact  | `imvu/account.pyo`, `shop/ShopMode.js`, `home/home.js`, `inbox/IphoneAd.html` |
| 4 | `no-tracking`| Disable "Send IMVU Logs" reporting + stop Bluecava device fingerprint collection (removes the call, then deletes `devicefingerprint.exe`) | `main/SendIMVULogs.pyo`, `imvu/mode/SettingsMode.pyo`, `imvu/imq/imqconnection.pyo`, `imvu/account.pyo`, deletes `devicefingerprint.exe` |
| 5 | `invite-timer` | Room invite timer 5 -> 15 minutes                                 | `dialogs/invited_to_chat/invited_to_chat.js`            |
| 6 | `hires-snap` | Hi-res snapshots anywhere + right-click menu items                  | `imvu/client/sessionwindow.pyo`                          |
| 7 | `chat-colors`| Nametag color randomizer button in chat header                      | `imvu/tool/ChatTool.pyo`, `tool/chat/*`, `tool/newchat/*` |
| 8 | `auto-mute`  | Auto-hide blocked users from chat (avatar, bubble, history) with red join/leave notices + header toggle | `imvu/client/sessionwindow.pyo`, `imvu/tool/ChatTool.pyo`, `tool/chat/*`, `tool/newchat/*` |

## How it works

- `patcher.py` reads each feature's `patch_spec.txt` and rewrites
  `library.zip` / `ui/chrome/imvuContent.jar` in place, then re-syncs the
  extracted `ui/chrome/imvucontentjar` directory and updates `checksum.txt`.
- Python `.pyo` files are shipped pre-patched (surgical code-tree swap of only
  the affected functions; all other code objects stay byte-identical to stock).
- JS/HTML edits are surgical find/replace against the pristine entry.
- A backup is taken before each patch and stored under
  `features\<name>\backup\<timestamp>\`. Use the menu's `[R]` to restore.
- `kind = delete` ops (e.g. `devicefingerprint.exe`) back the file up first,
  then remove it and prune its `checksum.txt` entry so the updater leaves it
  deleted. Restoring the backup brings the file and its checksum line back.

## Usage

```
patch.bat            interactive menu (apply / check / restore)
patcher.py --apply   apply all patches for the spec in this dir
patcher.py --check   report state for every entry
patcher.py --restore NAME
```

Per-feature CLI (e.g. camera):

```
py -3.8 patcher.py --client-root "%CLIENTROOT%" --spec-dir features\camera --check
py -3.8 patcher.py --client-root "%CLIENTROOT%" --spec-dir features\camera --apply
```

The original standalone `patch_spec.txt` in this folder (chat-colors) is now
superseded by `features\chat-colors\`; it is kept for reference.

## Upstream changes

Each spec records the `baseline` sha1 of the pristine entry it was authored
against (or uses a find-anchor for `patch` kinds). If IMVU updates and the
entry changes, `--check` reports `modified`; re-run with `--apply --force` only
if you are sure the anchor still applies.

Upgrading from a previous version of this suite: if you already applied `ads`
or `no-tracking` with an older `account.pyo`, `--check` will report
`imvu/account.pyo` as `modified` (its bytes differ from the new baseline).
Run `--apply --force` once for either feature to install the combined
`account.pyo` (ads disabled + Bluecava device-fingerprint collection removed);
after that, both features report `applied` regardless of apply order.

The same applies to the byte-shared entries between `hires-snap` / `auto-mute`
(`imvu/client/sessionwindow.pyo`) and `chat-colors` / `auto-mute`
(`imvu/tool/ChatTool.pyo` and the six `tool/chat|tool/newchat` files): the
shipped bytes are identical across those features, so if you already applied
`chat-colors` or `hires-snap` with an older version, run `--apply --force`
once for either of the affected features to install the combined file; after
that, all three features report `applied` regardless of apply order.

## Notes / scope

- Requires Python 3.8 (`py -3.8`); the shipped `.pyo` artifacts were compiled
  with Python 2.7.18 (64-bit) and verified against the 32-bit client bytecode.
- The main `patch_spec.txt` (chat-colors feature) continues to work unchanged.
